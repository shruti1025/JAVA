
public class HSSFSheet {

	public HSSFRow createRow(short s) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setColumnWidth(short s, short t) {
		// TODO Auto-generated method stub
		
	}

}
