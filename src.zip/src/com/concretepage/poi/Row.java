package com.concretepage.poi;

public class Row {

	public int getLastCellNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Object getHeight() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setHeight(Object height) {
		// TODO Auto-generated method stub
		
	}

	public int getRowNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getFirstCellNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Cell getCell(int j) {
		// TODO Auto-generated method stub
		return null;
	}

	public Cell createCell(int j) {
		// TODO Auto-generated method stub
		return null;
	}

}
