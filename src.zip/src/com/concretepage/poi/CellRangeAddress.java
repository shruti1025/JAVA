package com.concretepage.poi;

public class CellRangeAddress {

	public int getFirstRow() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getLastRow() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Object getFirstColumn() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isInRange(int rowNum, short cellNum) {
		// TODO Auto-generated method stub
		return false;
	}

	public Object getLastColumn() {
		// TODO Auto-generated method stub
		return null;
	}

}
