package com.concretepage.poi;

public class Cell {

	
	public static final int CELL_TYPE_NUMERIC = 0;
	public static int CELL_TYPE_BLANK;
	public static int CELL_TYPE_STRING;
	public static int CELL_TYPE_FORMULA;
	public static int CELL_TYPE_BOOLEAN;
	public static int CELL_TYPE_ERROR;

	public int getCellType() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Object getStringCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public short getColumnIndex() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Object getSheet() {
		// TODO Auto-generated method stub
		return null;
	}

	

	public void setCellStyle(Object cellStyle) {
		// TODO Auto-generated method stub
		
	}

	

	public Object getCellStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getErrorCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getCellFormula() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCellFormula(Object cellFormula) {
		// TODO Auto-generated method stub
		
	}

	public Object getBooleanCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getNumericCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCellValue(Object stringCellValue) {
		// TODO Auto-generated method stub
		
	}

	public void setCellType(String cellTypeBlank) {
		// TODO Auto-generated method stub
		
	}

	public void setCellErrorValue(Object errorCellValue) {
		// TODO Auto-generated method stub
		
	}
	
	public int getWorkbook()
	{
		return 0;
	
	}
	
	public void createCellStyle()
	{
		
	}
	
	

}
