package com.concretepage.poi;

public class HSSFCell {

	public static final String CELL_TYPE_BLANK = null;

}
