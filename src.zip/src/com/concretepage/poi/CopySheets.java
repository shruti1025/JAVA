package com.concretepage.poi;



import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.lang.Object;

public class CopySheets {

public Workbook mergeExcelFiles(Workbook book, List<InputStream> inList) throws IOException {

    for (InputStream fin : inList) {
        Workbook b = WorkbookFactory.create(fin);
         for (int i = 0; i < b.getNumberOfSheets(); i++) {
            // not entering sheet name, because of duplicated names
            copySheets(book.createSheet(),b.getSheetAt(i));
        }
    }
    return book;
}

public static void copySheets(Sheet newSheet, Sheet sheet){     
    copySheets(newSheet, sheet, true);     
}

public static void copySheets(Sheet newSheet, Sheet sheet, boolean copyStyle){     
    int maxColumnNum = 0;     
    Map<Integer, CellStyle> styleMap = (copyStyle) ? new HashMap<Integer, CellStyle>() : null;     
    for (int i = sheet.getFirstRowNum(); i <= sheet.getLastRowNum(); i++) {     
        Row srcRow = sheet.getRow(i);     
        Row destRow = newSheet.createRow(i);     
        if (srcRow != null) {     
            copyRow(sheet, newSheet, srcRow, destRow, styleMap);     
            if (srcRow.getLastCellNum() > maxColumnNum) {     
                maxColumnNum = srcRow.getLastCellNum();     
            }     
        }     
    }     
    for (int i = 0; i <= maxColumnNum; i++) {     
        newSheet.setColumnWidth(i, sheet.getColumnWidth(i));     
    }     
}     

public static void copyRow(Sheet srcSheet, Sheet destSheet, Row srcRow, Row destRow, Map<Integer, CellStyle> styleMap) {     
    // manage a list of merged zone in order to not insert two times a merged zone  
  Set<CellRangeAddressWrapper> mergedRegions = new TreeSet<CellRangeAddressWrapper>();     
    destRow.setHeight(srcRow.getHeight());     
    // reckoning delta rows  
    int deltaRows = destRow.getRowNum()-srcRow.getRowNum();  
    
    for (int j = srcRow.getFirstCellNum(); j <= srcRow.getLastCellNum(); j++) {     
        Cell oldCell = srcRow.getCell(j);    
        Cell newCell = destRow.getCell(j);  // new cell   
        if (oldCell != null) {     
            if (newCell == null) {     
                newCell = destRow.createCell(j);     
            }     
           
            copyCell(oldCell, newCell, styleMap);     
            
            CellRangeAddress mergedRegion = getMergedRegion(srcSheet, srcRow.getRowNum(), (short)oldCell.getColumnIndex());     

            if (mergedRegion != null) {   
              
              CellRangeAddress newMergedRegion = new CellRangeAddress();  
                
                CellRangeAddressWrapper wrapper = new CellRangeAddressWrapper(newMergedRegion);  
                if (isNewMergedRegion(wrapper, mergedRegions)) {  
                    mergedRegions.add(wrapper);  
                    destSheet.addMergedRegion(wrapper.range);     
                }     
            }     
        }     
    }                
}

public static void copyCell(Cell oldCell, Cell newCell, Map<Integer, CellStyle> styleMap) {     
    if(styleMap != null) {     
        if(((Cell) oldCell.getSheet()).getWorkbook() == ((Cell) newCell.getSheet()).getWorkbook()){     
            newCell.setCellStyle(oldCell.getCellStyle());     
        } else{     
            int stHashCode = oldCell.getCellStyle().hashCode();     
            CellStyle newCellStyle = styleMap.get(stHashCode);     
            if(newCellStyle == null){     
                newCellStyle =  ((Cell) newCell.getSheet())).getWorkbook().createCellStyle();     
                newCellStyle.cloneStyleFrom(oldCell.getCellStyle());     
                styleMap.put(stHashCode, newCellStyle);     
            }     
            newCell.setCellStyle(newCellStyle);     
        }     
    }     
    switch(oldCell.getCellType()) {     
    case Cell.CELL_TYPE_STRING:     
        newCell.setCellValue(oldCell.getStringCellValue());     
        break;     
  case Cell.CELL_TYPE_NUMERIC:     
        newCell.setCellValue(oldCell.getNumericCellValue());     
        break;     
  case Cell.CELL_TYPE_BLANK:     
        newCell.setCellType(HSSFCell.CELL_TYPE_BLANK);     
        break;     
  case Cell.CELL_TYPE_BOOLEAN:     
        newCell.setCellValue(oldCell.getBooleanCellValue());     
        break;     
  case Cell.CELL_TYPE_ERROR:     
        newCell.setCellErrorValue(oldCell.getErrorCellValue());     
        break;     
  case Cell.CELL_TYPE_FORMULA:     
        newCell.setCellFormula(oldCell.getCellFormula());     
        break;     
  default:     
        break;     
    }     

}

public static CellRangeAddress getMergedRegion(Sheet sheet, int rowNum, short cellNum) {     
    for (int i = 0; i < sheet.getNumMergedRegions(); i++) {   
        CellRangeAddress merged = sheet.getMergedRegion(i);     
        if (merged.isInRange(rowNum, cellNum)) {     
            return merged;     
        }     
    }     
    return null;     
}     

private static boolean isNewMergedRegion(CellRangeAddressWrapper newMergedRegion, Set<CellRangeAddressWrapper> mergedRegions) {  
	  return !mergedRegions.contains(newMergedRegion);     
	}     

	}
	class CellRangeAddressWrapper implements Comparable<CellRangeAddressWrapper> {  

	public CellRangeAddress range;  

	
	public CellRangeAddressWrapper(CellRangeAddress theRange) {  
	      this.range = theRange;  
	}  
	
	public int compareTo(CellRangeAddressWrapper o) {  
		
        if ((range.getFirstColumn() < o.range.getFirstColumn()) && (range.getFirstRow() < o.range.getFirstRow())) {  
              return -1;  
        } else if (range.getFirstColumn() == o.range.getFirstColumn()  
                    && range.getFirstRow() == o.range.getFirstRow()) {  
              return 0;  
        } else {  
              return 1;  
        }  

}  

}  
	
	



