package org.apache.poi.hssf.usermodel;

public class HSSFRow {

	public int getFirstCellNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getLastCellNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public HSSFCell getCell(int iCell) {
		// TODO Auto-generated method stub
		return null;
	}

	public HSSFCell createCell(int iCell) {
		// TODO Auto-generated method stub
		return null;
	}

}
