package org.apache.poi.hssf.usermodel;

public class HSSFSheet {

	public Object getSheetName() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getFirstRowNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getLastRowNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public HSSFRow getRow(int iRow) {
		// TODO Auto-generated method stub
		return null;
	}

	public HSSFRow createRow(int iRow) {
		// TODO Auto-generated method stub
		return null;
	}

}
