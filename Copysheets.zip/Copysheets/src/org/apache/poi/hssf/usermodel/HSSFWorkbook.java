package org.apache.poi.hssf.usermodel;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;

public class HSSFWorkbook {

	public HSSFWorkbook(BufferedInputStream bis) {
		// TODO Auto-generated constructor stub
	}

	public HSSFWorkbook() {
		// TODO Auto-generated constructor stub
	}

	public int getNumberOfSheets() {
		// TODO Auto-generated method stub
		return 0;
	}

	public HSSFSheet getSheetAt(int iSheet) {
		// TODO Auto-generated method stub
		return null;
	}

	public HSSFSheet createSheet(Object sheetName) {
		// TODO Auto-generated method stub
		return null;
	}

	public void write(BufferedOutputStream bos) {
		// TODO Auto-generated method stub
		
	}

}
