package org.apache.poi.hssf.usermodel;

public class HSSFCell {

	public static Object CELL_TYPE_BLANK;
	public static Object CELL_TYPE_BOOLEAN;
	public static Object CELL_TYPE_ERROR;
	public static Object CELL_TYPE_FORMULA;
	public static Object CELL_TYPE_NUMERIC;
	public static Object CELL_TYPE_STRING;

	public Object getCellType() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCellType(Object cellType) {
		// TODO Auto-generated method stub
		
	}

	public Object getCellFormula() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCellFormula(Object cellFormula) {
		// TODO Auto-generated method stub
		
	}

	public Object getStringCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCellValue(Object stringCellValue) {
		// TODO Auto-generated method stub
		
	}

	public Object getNumericCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getErrorCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getBooleanCellValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCellErrorValue(Object errorCellValue) {
		// TODO Auto-generated method stub
		
	}

}
