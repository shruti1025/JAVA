package com.concretepage.poi;

import java.io.InputStream;

public class WorkbookFactory {

	public static Workbook create(InputStream fin) {
		// TODO Auto-generated method stub
		return null;
	}

}
