package com.concretepage.poi;

public class Workbook {

	public int getNumberOfSheets() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Sheet createSheet() {
		// TODO Auto-generated method stub
		return null;
	}

	public Sheet getSheetAt(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
