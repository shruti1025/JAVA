package com.concretepage.poi;

public class CellStyle {

	public void cloneStyleFrom(Object cellStyle) {
		// TODO Auto-generated method stub
		
	}

}
