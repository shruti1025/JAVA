package com.concretepage.poi;

public class Sheet {

	public int getFirstRowNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getLastRowNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Row getRow(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	public Row createRow(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getColumnWidth(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setColumnWidth(int i, Object columnWidth) {
		// TODO Auto-generated method stub
		
	}

	public void addMergedRegion(CellRangeAddress range) {
		// TODO Auto-generated method stub
		
	}

	public int getNumMergedRegions() {
		// TODO Auto-generated method stub
		return 0;
	}

	public CellRangeAddress getMergedRegion(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
