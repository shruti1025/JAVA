
public class HSSFRow {

	public Object createCell(short s) {
		// TODO Auto-generated method stub
		return null;
	}

}
