
public class HSSFRichTextString {

	public HSSFRichTextString(String string) {
		// TODO Auto-generated constructor stub
	}



}
