import java.io.*;
import java.sql.*;
import java.util.*;


public class MysqlToXls {
	
	private Connection connection = null;
	
	public MysqlToXls(String string, String string2, String string3) {
		// TODO Auto-generated constructor stub
	}

	public void MysqlToxls(String database, String user, String password) 
			throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		
		String url = "jdbc:mysql://localhost:3306/" + database;
		connection = DriverManager.getConnection(url, user, password);
	}
	
	public void generateXls(String tablename, String filename)
	throws SQLException, FileNotFoundException, IOException {
		
		HSSFWorkbook xlsWorkbook = new HSSFWorkbook();
		HSSFSheet xlsSheet = xlsWorkbook.createSheet();
		short rowIndex = 0;
		
		PreparedStatement stmt = connection.prepareStatement("select * from " + tablename);
		ResultSet rs = stmt.executeQuery();
		
		ResultSetMetaData colInfo = rs.getMetaData();
		List colNames = new ArrayList();
		HSSFRow titleRow = xlsSheet.createRow(rowIndex++);
		
		for(int i = 1; i <= colInfo.getColumnCount();i++) 
		{
			colNames.add(colInfo.getColumnName(i));
			titleRow.createCell((short) (i-1)).setCellvalue(
					new HSSFRichTextString(colInfo.getColumnName(i)));
			xlsSheet.setColumnWidth(( short) (i-1) , (short) 4000);
		}
		
		while (rs.next()) {
			HSSFRow dataRow = xlsSheet.createRow(rowIndex++);
			short colIndex = 0;
			for (String colName : colNames) {
				dataRow.createCell(colIndex++).setCellValue(
						new HSSFRichTextString(rs.getString(colName)));
				
			}
			
		}
		
		xlsWorkbook.write(new FileOutputStream(filename));
	}
	
	public static void mai(String[] args) {
		try{
			MysqlToXls mysqlToXls = new MysqlToXls("test" , "root", "");
			mysqlToXls.generateXls("person", "person.xls");
			mysqlToXls.close();
			} catch (Exception e) {
				
				e.printStackTrace();
			                      
			}
		
	}

	private void close() {
		// TODO Auto-generated method stub
		
	}
} 


