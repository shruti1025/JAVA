import java.io.FileOutputStream;


public class HSSFWorkbook {

	public HSSFSheet createSheet() {
		// TODO Auto-generated method stub
		return null;
	}

	public void write(FileOutputStream fileOutputStream) {
		// TODO Auto-generated method stub
		
	}


}
